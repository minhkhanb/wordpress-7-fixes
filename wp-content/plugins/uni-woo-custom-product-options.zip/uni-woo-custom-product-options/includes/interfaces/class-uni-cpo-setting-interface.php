<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Uni Cpo Setting Interface
 *
 * @category Interface
 */
interface Uni_Cpo_Setting_Interface {
	public function js_template();
}
