<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Uni Cpo Option Data Store Interface
 *
 * @category Interface
 */
interface Uni_Cpo_Option_Data_Store_Interface {
	//public function create( &$data );
}
